# Repository Badges

![Architecture](https://img.shields.io/badge/Architecture-Locked-darkgreen)
![Constitution](https://img.shields.io/badge/Constitution-v1.0.0-blue)
![CORE](https://img.shields.io/badge/CORE-v1.0.0-black)
![LAB](https://img.shields.io/badge/LAB-v1.2-blueviolet)
![CONTROL](https://img.shields.io/badge/CONTROL-External-lightgrey)
