# CHANGELOG

## v1.0.0 — Architecture Freeze

### Added
- Constitutional Addendum A (System Boundary & Admission)
- CONTROL Domain formalization (Template + SPB)
- Explicit ingestion-boundary validity creation
- Ontological clarification of rejection

### Locked
- CORE deterministic execution model
- LAB governance boundary
- CONTROL external tooling status

Architecture declared constitutionally frozen.
