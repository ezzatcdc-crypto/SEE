Phase2C_Output
      |
      v
[0] Canonicalizer
      |
      v
[1] IR Builder
      |
      v
[2] Guard Verifier
      |
      v
[3] Deterministic Rewriter
      |
      v
[4] Template Renderer
      |
      v
Guarded Narrative
