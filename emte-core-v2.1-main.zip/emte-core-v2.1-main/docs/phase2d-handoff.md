Phase 2D – Implementation handoff

This project includes a fully specified Interpretive Guard Layer (IGL).

The following specs are authoritative and MUST be implemented as-is:

1. Input contract

spec/phase2c-output-contract.yaml

2. Interpretation IR

spec/phase2d-interpretation-ir.yaml

3. Guard policy

spec/phase2d-interpretive-guard-policy.yaml

4. Controlled narrative language

spec/phase2d-controlled-narrative-templates.yaml

5. Test vectors

spec/phase2d-guard-test-vectors.yaml

6. Execution order

docs/phase2d-execution-pipeline.md

Non-negotiable constraints

Phase 2D MUST NOT:

modify Phase 2C thresholds

modify Phase 2C detectors

feed results back to Phase 2C

introduce causal, actor or intent inference

Phase 2D MUST:

be deterministic

follow the pipeline order exactly

pass all test vectors

Any deviation from these documents requires explicit design approval.
