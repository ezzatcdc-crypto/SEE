from __future__ import annotations
from dataclasses import dataclass
from typing import Optional, List


# ---- Data models ----

@dataclass(frozen=True)
class EligibilitySnapshot:
    resource_mass: bool
    agreement_mass: bool
    tar_present: bool
    baseline_sedv_ok: bool
    acceleration_gt_collapse: bool


    def all_true(self) -> bool:
        return (
            self.resource_mass
            and self.agreement_mass
            and self.tar_present
            and self.baseline_sedv_ok
            and self.acceleration_gt_collapse
        )


@dataclass(frozen=True)
class DeferredCandidate:
    snapshot: EligibilitySnapshot
    snapshot_hash: str
    voice_snapshot_id: str


@dataclass(frozen=True)
class RevalidateResult:
    all_true: bool
    failed_criteria: List[str]


@dataclass(frozen=True)
class ExecutionDecision:
    executed: bool
    dropped: bool
    reason: Optional[str] = None


# ---- Core logic ----

def build_failed_criteria(snapshot: EligibilitySnapshot) -> List[str]:
    failed = []
    if not snapshot.resource_mass:
        failed.append("resource_mass")
    if not snapshot.agreement_mass:
        failed.append("agreement_mass")
    if not snapshot.tar_present:
        failed.append("tar_present")
    if not snapshot.baseline_sedv_ok:
        failed.append("baseline_sedv")
    if not snapshot.acceleration_gt_collapse:
        failed.append("acceleration_gt_collapse")
    return failed


def update_deferred_candidate(
    *,
    existing: Optional[DeferredCandidate],
    snapshot: EligibilitySnapshot,
    snapshot_hash: str,
    voice_snapshot_id: str,
) -> Optional[DeferredCandidate]:
    """
    During S2 only.

    - Create candidate if snapshot.all_true
    - Overwrite existing candidate (no queue)
    - If snapshot is not eligible -> do nothing (keep existing)
    """

    if not snapshot.all_true():
        return existing

    return DeferredCandidate(
        snapshot=snapshot,
        snapshot_hash=snapshot_hash,
        voice_snapshot_id=voice_snapshot_id,
    )


def revalidate_after_freeze(snapshot: EligibilitySnapshot) -> RevalidateResult:
    failed = build_failed_criteria(snapshot)
    return RevalidateResult(
        all_true=(len(failed) == 0),
        failed_criteria=failed,
    )


def execution_latch_post_freeze(
    *,
    revalidate: RevalidateResult,
    has_deferred_candidate: bool,
    execution_already_in_tick: bool,
) -> ExecutionDecision:
    """
    Enforces:
      - single execution per tick
      - after revalidate:
          all_true  -> execute once
          failed    -> drop deferred (if any)
    """

    if execution_already_in_tick:
        return ExecutionDecision(
            executed=False,
            dropped=False,
            reason="execution_already_performed_in_tick",
        )

    if revalidate.all_true:
        return ExecutionDecision(
            executed=True,
            dropped=False,
            reason="post_freeze_release_execution",
        )

    # failed
    if has_deferred_candidate:
        return ExecutionDecision(
            executed=False,
            dropped=True,
            reason="revalidate_failed",
        )

    return ExecutionDecision(
        executed=False,
        dropped=False,
        reason="revalidate_failed_no_candidate",
    )

