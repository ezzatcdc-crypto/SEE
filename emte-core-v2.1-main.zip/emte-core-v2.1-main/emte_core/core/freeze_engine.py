from __future__ import annotations
from dataclasses import dataclass
from enum import Enum
from typing import Optional


class FreezeState(str, Enum):
    S0 = "S0"  # Inactive
    S1 = "S1"  # Armed
    S2 = "S2"  # Active freeze
    S3 = "S3"  # Expired marker


@dataclass(frozen=True)
class FreezeContext:
    # inputs
    emergency_flag: bool
    acceleration: float
    collapse_momentum: float
    now_day: int  # simple discrete time (days) for deterministic tests

    # state
    state: FreezeState
    s1_start_day: Optional[int] = None
    s2_start_day: Optional[int] = None
    s2_hard_end_day: Optional[int] = None
    next_review_due_day: Optional[int] = None  # used only in S2


@dataclass(frozen=True)
class FreezeTransition:
    from_state: FreezeState
    to_state: FreezeState
    transition_day: int
    # optional S2 metadata
    s2_start_day: Optional[int] = None
    s2_hard_end_day: Optional[int] = None


@dataclass(frozen=True)
class FreezeStepResult:
    new_ctx: FreezeContext
    transition: Optional[FreezeTransition]
    # For now we expose "needs_review" flag; review mechanics is tested separately later.
    needs_review: bool = False


S1_MAX_DAYS = 14
S2_MAX_DAYS = 183  # ~6 months (fixed window). Keep deterministic in tests.
REVIEW_CADENCE_DAYS = 42  # 6 weeks


def acc_gt_cm(acc: float, cm: float) -> bool:
    return acc > cm


def acc_le_cm(acc: float, cm: float) -> bool:
    return acc <= cm


def step_freeze(ctx: FreezeContext) -> FreezeStepResult:
    """
    EMTE v2.1 Freeze lifecycle core:
      - S0 -> S1 iff flag=TRUE and Acc<=CM
      - S1 -> S0 iff Acc>CM
      - S1 -> S2 decision point when Acc<=CM (caller can invoke after verification window)
      - S2 -> S0 iff review_valid and Acc>CM (review signal handled outside; here we only surface due reviews)
      - S2 -> S3 iff now>=hard_end
      - S3 -> S0 immediate next step
    This function does NOT implement escalation or review validity logic.
    It only maintains state + timing guards deterministically.
    """

    now = ctx.now_day

    # State closure
    if ctx.state not in (FreezeState.S0, FreezeState.S1, FreezeState.S2, FreezeState.S3):
        raise ValueError("Invalid freeze state")

    # S0
    if ctx.state == FreezeState.S0:
        if ctx.emergency_flag and acc_le_cm(ctx.acceleration, ctx.collapse_momentum):
            new_ctx = FreezeContext(
                emergency_flag=ctx.emergency_flag,
                acceleration=ctx.acceleration,
                collapse_momentum=ctx.collapse_momentum,
                now_day=now,
                state=FreezeState.S1,
                s1_start_day=now,
            )
            tr = FreezeTransition(FreezeState.S0, FreezeState.S1, now)
            return FreezeStepResult(new_ctx, tr, needs_review=False)
        return FreezeStepResult(ctx, None, needs_review=False)

    # S1
    if ctx.state == FreezeState.S1:
        if ctx.s1_start_day is None:
            raise ValueError("S1 requires s1_start_day")

        # Invariant: S1 window must not exceed 14 days
        if now - ctx.s1_start_day > S1_MAX_DAYS:
            raise RuntimeError("Invariant breach: S1 exceeded 14 days")

        # Disarm if recovery
        if acc_gt_cm(ctx.acceleration, ctx.collapse_momentum):
            new_ctx = FreezeContext(
                emergency_flag=ctx.emergency_flag,
                acceleration=ctx.acceleration,
                collapse_momentum=ctx.collapse_momentum,
                now_day=now,
                state=FreezeState.S0,
            )
            tr = FreezeTransition(FreezeState.S1, FreezeState.S0, now)
            return FreezeStepResult(new_ctx, tr, needs_review=False)

        # Otherwise remain S1; activation to S2 is an explicit decision (separate function below)
        return FreezeStepResult(ctx, None, needs_review=False)

    # S2
    if ctx.state == FreezeState.S2:
        if ctx.s2_start_day is None or ctx.s2_hard_end_day is None or ctx.next_review_due_day is None:
            raise ValueError("S2 requires s2_start_day, s2_hard_end_day, next_review_due_day")

        # Hard expiry
        if now >= ctx.s2_hard_end_day:
            new_ctx = FreezeContext(
                emergency_flag=ctx.emergency_flag,
                acceleration=ctx.acceleration,
                collapse_momentum=ctx.collapse_momentum,
                now_day=now,
                state=FreezeState.S3,
                s2_start_day=ctx.s2_start_day,
                s2_hard_end_day=ctx.s2_hard_end_day,
                next_review_due_day=ctx.next_review_due_day,
            )
            tr = FreezeTransition(FreezeState.S2, FreezeState.S3, now, ctx.s2_start_day, ctx.s2_hard_end_day)
            return FreezeStepResult(new_ctx, tr, needs_review=False)

        # Review scheduling signal
        needs_review = now >= ctx.next_review_due_day
        return FreezeStepResult(ctx, None, needs_review=needs_review)

    # S3 -> S0 (immediate)
    if ctx.state == FreezeState.S3:
        new_ctx = FreezeContext(
            emergency_flag=ctx.emergency_flag,
            acceleration=ctx.acceleration,
            collapse_momentum=ctx.collapse_momentum,
            now_day=now,
            state=FreezeState.S0,
        )
        tr = FreezeTransition(FreezeState.S3, FreezeState.S0, now)
        return FreezeStepResult(new_ctx, tr, needs_review=False)

    raise AssertionError("Unreachable")


def activate_freeze_from_s1(ctx: FreezeContext) -> FreezeStepResult:
    """
    Explicit activation decision after verification window:
      S1 -> S2 iff Acc<=CM, within 14 days window.
    Sets:
      s2_start_day = now
      s2_hard_end_day = now + S2_MAX_DAYS
      next_review_due_day = now + REVIEW_CADENCE_DAYS
    """
    if ctx.state != FreezeState.S1:
        raise ValueError("activate_freeze_from_s1 requires state S1")
    if ctx.s1_start_day is None:
        raise ValueError("S1 requires s1_start_day")
    now = ctx.now_day
    if now - ctx.s1_start_day > S1_MAX_DAYS:
        raise RuntimeError("Invariant breach: S1 exceeded 14 days")
    if acc_gt_cm(ctx.acceleration, ctx.collapse_momentum):
        # if recovery, do not activate
        return step_freeze(ctx)

    # Acc<=CM -> activate
    new_ctx = FreezeContext(
        emergency_flag=ctx.emergency_flag,
        acceleration=ctx.acceleration,
        collapse_momentum=ctx.collapse_momentum,
        now_day=now,
        state=FreezeState.S2,
        s1_start_day=ctx.s1_start_day,
        s2_start_day=now,
        s2_hard_end_day=now + S2_MAX_DAYS,
        next_review_due_day=now + REVIEW_CADENCE_DAYS,
    )
    tr = FreezeTransition(FreezeState.S1, FreezeState.S2, now, new_ctx.s2_start_day, new_ctx.s2_hard_end_day)
    return FreezeStepResult(new_ctx, tr, needs_review=False)


def lift_freeze_from_s2(ctx: FreezeContext, *, review_valid: bool) -> FreezeStepResult:
    """
    Early lift:
      S2 -> S0 iff review_valid == True AND Acc>CM
    If not met, stays S2.
    Also advances next_review_due_day when a review is processed (valid or not).
    """
    if ctx.state != FreezeState.S2:
        raise ValueError("lift_freeze_from_s2 requires state S2")
    if ctx.next_review_due_day is None:
        raise ValueError("S2 requires next_review_due_day")
    now = ctx.now_day

    # If hard expiry already reached, let step_freeze handle it.
    if ctx.s2_hard_end_day is not None and now >= ctx.s2_hard_end_day:
        return step_freeze(ctx)

    # advance review schedule on every processed review
    advanced_ctx = FreezeContext(
        emergency_flag=ctx.emergency_flag,
        acceleration=ctx.acceleration,
        collapse_momentum=ctx.collapse_momentum,
        now_day=now,
        state=ctx.state,
        s1_start_day=ctx.s1_start_day,
        s2_start_day=ctx.s2_start_day,
        s2_hard_end_day=ctx.s2_hard_end_day,
        next_review_due_day=now + REVIEW_CADENCE_DAYS,
    )

    if review_valid and acc_gt_cm(ctx.acceleration, ctx.collapse_momentum):
        new_ctx = FreezeContext(
            emergency_flag=advanced_ctx.emergency_flag,
            acceleration=advanced_ctx.acceleration,
            collapse_momentum=advanced_ctx.collapse_momentum,
            now_day=now,
            state=FreezeState.S0,
        )
        tr = FreezeTransition(FreezeState.S2, FreezeState.S0, now, ctx.s2_start_day, ctx.s2_hard_end_day)
        return FreezeStepResult(new_ctx, tr, needs_review=False)

    return FreezeStepResult(advanced_ctx, None, needs_review=False)

