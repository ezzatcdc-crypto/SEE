from __future__ import annotations
from dataclasses import dataclass
from enum import Enum

from emte_core.core.freeze_engine import FreezeState


class GateState(str, Enum):
    G0 = "G0"  # Open
    G1 = "G1"  # Held
    G2 = "G2"  # Release pending


@dataclass(frozen=True)
class GateDecision:
    gate_state: GateState
    execution_allowed: bool


def gate_from_freeze_state(freeze_state: FreezeState) -> GateDecision:
    """
    EMTE v2.1 Gate mapping (hard invariant)

    S2 -> G1 (Held)
    S1 -> G2 (Release pending)
    S0 -> G0 (Open)
    S3 must never be visible to execution layer (handled before gate mapping)

    execution_allowed:
      only when gate_state == G0
    """

    if freeze_state == FreezeState.S2:
        return GateDecision(
            gate_state=GateState.G1,
            execution_allowed=False,
        )

    if freeze_state == FreezeState.S1:
        return GateDecision(
            gate_state=GateState.G2,
            execution_allowed=False,
        )

    if freeze_state == FreezeState.S0:
        return GateDecision(
            gate_state=GateState.G0,
            execution_allowed=True,
        )

    # S3 must not reach the gate layer
    raise RuntimeError("Invalid freeze state for gate mapping (S3 must be resolved before gate)")

