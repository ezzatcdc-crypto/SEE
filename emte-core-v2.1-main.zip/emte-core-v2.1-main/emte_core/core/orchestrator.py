from __future__ import annotations
from dataclasses import dataclass
from typing import Optional

from emte_core.core.flag_engine import evaluate_emergency_flag
from emte_core.core.freeze_engine import (
    FreezeContext,
    FreezeState,
    step_freeze,
    activate_freeze_from_s1,
    lift_freeze_from_s2,
)
from emte_core.core.gate_engine import gate_from_freeze_state, GateDecision
from emte_core.core.deferred_engine import (
    EligibilitySnapshot,
    DeferredCandidate,
    update_deferred_candidate,
    revalidate_after_freeze,
    execution_latch_post_freeze,
    ExecutionDecision,
)


@dataclass(frozen=True)
class TickInputs:
    # ----- emergency signal layer -----
    previous_emergency_flag: bool
    delta_sedv_6m: float
    ew_band_on_used: float

    # ----- freeze / acceleration layer -----
    acceleration: float
    collapse_momentum: float
    now_day: int

    # ----- eligibility snapshot (threshold layer) -----
    eligibility: EligibilitySnapshot

    # ----- control plane -----
    review_valid: bool = False


@dataclass(frozen=True)
class TickState:
    emergency_flag: bool
    freeze_ctx: FreezeContext
    deferred_candidate: Optional[DeferredCandidate]
    execution_already_in_tick: bool = False


@dataclass(frozen=True)
class TickResult:
    emergency_flag: bool
    freeze_ctx: FreezeContext
    gate: GateDecision
    deferred_candidate: Optional[DeferredCandidate]
    execution: ExecutionDecision


def run_tick(
    *,
    inputs: TickInputs,
    state: TickState,
) -> TickResult:

    # ---------------------------------------------------------
    # 1. Emergency flag evaluation
    # ---------------------------------------------------------
    flag_decision = evaluate_emergency_flag(
        previous_flag=state.emergency_flag,
        delta_sedv_6m=inputs.delta_sedv_6m,
        ew_band_on_used=inputs.ew_band_on_used,
    )

    emergency_flag = flag_decision.new_flag

    # ---------------------------------------------------------
    # 2. Freeze step
    # ---------------------------------------------------------
    freeze_input_ctx = FreezeContext(
        emergency_flag=emergency_flag,
        acceleration=inputs.acceleration,
        collapse_momentum=inputs.collapse_momentum,
        now_day=inputs.now_day,
        state=state.freeze_ctx.state,
        s1_start_day=state.freeze_ctx.s1_start_day,
        s2_start_day=state.freeze_ctx.s2_start_day,
        s2_hard_end_day=state.freeze_ctx.s2_hard_end_day,
        next_review_due_day=state.freeze_ctx.next_review_due_day,
    )

    freeze_step = step_freeze(freeze_input_ctx)
    freeze_ctx = freeze_step.new_ctx

    # ---------------------------------------------------------
    # 3. Explicit transitions
    # ---------------------------------------------------------
    # Activation: S1 -> S2 is explicit (policy decision layer)
    if freeze_ctx.state == FreezeState.S1 and state.freeze_ctx.state == FreezeState.S1:
        if freeze_step.transition is None:
            # activation only when still S1 and no auto transition happened
            freeze_activation = activate_freeze_from_s1(freeze_ctx)
            freeze_ctx = freeze_activation.new_ctx

    # Early lift: only when review is provided
    if freeze_ctx.state == FreezeState.S2 and inputs.review_valid:
        freeze_lift = lift_freeze_from_s2(freeze_ctx, review_valid=True)
        freeze_ctx = freeze_lift.new_ctx

    # ---------------------------------------------------------
    # 4. Gate
    # ---------------------------------------------------------
    # S3 must never reach gate layer; step_freeze resolves it next tick
    if freeze_ctx.state == FreezeState.S3:
        gate = None  # not exposed this tick
    else:
        gate = gate_from_freeze_state(freeze_ctx.state)

    # ---------------------------------------------------------
    # 5. Deferred candidate collection (only during S2)
    # ---------------------------------------------------------
    deferred_candidate = state.deferred_candidate

    if freeze_ctx.state == FreezeState.S2:
        deferred_candidate = update_deferred_candidate(
            existing=deferred_candidate,
            snapshot=inputs.eligibility,
            snapshot_hash="tick-" + str(inputs.now_day),
            voice_snapshot_id="voice-" + str(inputs.now_day),
        )

    # ---------------------------------------------------------
    # 6. Revalidate & execution latch
    # ---------------------------------------------------------
    if state.freeze_ctx.state == FreezeState.S2 and freeze_ctx.state == FreezeState.S0:
        # just released from freeze
        reval = revalidate_after_freeze(inputs.eligibility)

        execution = execution_latch_post_freeze(
            revalidate=reval,
            has_deferred_candidate=deferred_candidate is not None,
            execution_already_in_tick=state.execution_already_in_tick,
        )

        if execution.dropped:
            deferred_candidate = None

    else:
        execution = ExecutionDecision(
            executed=False,
            dropped=False,
            reason="no_release_event",
        )

    return TickResult(
        emergency_flag=emergency_flag,
        freeze_ctx=freeze_ctx,
        gate=gate,
        deferred_candidate=deferred_candidate,
        execution=execution,
    )
