from emte_core.core.deferred_engine import (
    EligibilitySnapshot,
    DeferredCandidate,
    update_deferred_candidate,
    revalidate_after_freeze,
    execution_latch_post_freeze,
)


def ok_snapshot():
    return EligibilitySnapshot(
        resource_mass=True,
        agreement_mass=True,
        tar_present=True,
        baseline_sedv_ok=True,
        acceleration_gt_collapse=True,
    )


def bad_snapshot():
    return EligibilitySnapshot(
        resource_mass=True,
        agreement_mass=False,
        tar_present=True,
        baseline_sedv_ok=True,
        acceleration_gt_collapse=True,
    )


def test_create_deferred_candidate():
    c = update_deferred_candidate(
        existing=None,
        snapshot=ok_snapshot(),
        snapshot_hash="h1",
        voice_snapshot_id="v1",
    )
    assert c is not None
    assert c.snapshot_hash == "h1"


def test_overwrite_deferred_candidate():
    first = DeferredCandidate(
        snapshot=ok_snapshot(),
        snapshot_hash="h1",
        voice_snapshot_id="v1",
    )
    second = update_deferred_candidate(
        existing=first,
        snapshot=ok_snapshot(),
        snapshot_hash="h2",
        voice_snapshot_id="v2",
    )
    assert second.snapshot_hash == "h2"


def test_do_not_create_if_not_eligible():
    c = update_deferred_candidate(
        existing=None,
        snapshot=bad_snapshot(),
        snapshot_hash="h1",
        voice_snapshot_id="v1",
    )
    assert c is None


def test_revalidate_all_true():
    r = revalidate_after_freeze(ok_snapshot())
    assert r.all_true is True
    assert r.failed_criteria == []


def test_revalidate_failed():
    r = revalidate_after_freeze(bad_snapshot())
    assert r.all_true is False
    assert "agreement_mass" in r.failed_criteria


def test_execution_after_successful_revalidate():
    r = revalidate_after_freeze(ok_snapshot())
    d = execution_latch_post_freeze(
        revalidate=r,
        has_deferred_candidate=True,
        execution_already_in_tick=False,
    )
    assert d.executed is True
    assert d.dropped is False


def test_drop_after_failed_revalidate_with_candidate():
    r = revalidate_after_freeze(bad_snapshot())
    d = execution_latch_post_freeze(
        revalidate=r,
        has_deferred_candidate=True,
        execution_already_in_tick=False,
    )
    assert d.executed is False
    assert d.dropped is True


def test_no_double_execution_in_same_tick():
    r = revalidate_after_freeze(ok_snapshot())
    d = execution_latch_post_freeze(
        revalidate=r,
        has_deferred_candidate=True,
        execution_already_in_tick=True,
    )
    assert d.executed is False

