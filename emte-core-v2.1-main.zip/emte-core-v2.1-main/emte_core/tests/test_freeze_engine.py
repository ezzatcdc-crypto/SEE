import pytest
from emte_core.core.freeze_engine import (
    FreezeContext, FreezeState,
    step_freeze, activate_freeze_from_s1, lift_freeze_from_s2,
    S1_MAX_DAYS, REVIEW_CADENCE_DAYS, S2_MAX_DAYS
)

def ctx(state, now, flag=False, acc=0.0, cm=0.0, s1=None, s2=None, end=None, next_rev=None):
    return FreezeContext(
        emergency_flag=flag,
        acceleration=acc,
        collapse_momentum=cm,
        now_day=now,
        state=state,
        s1_start_day=s1,
        s2_start_day=s2,
        s2_hard_end_day=end,
        next_review_due_day=next_rev,
    )

def test_s0_to_s1_when_flag_and_acc_le_cm():
    r = step_freeze(ctx(FreezeState.S0, now=0, flag=True, acc=1, cm=2))
    assert r.new_ctx.state == FreezeState.S1
    assert r.transition is not None and r.transition.from_state == FreezeState.S0 and r.transition.to_state == FreezeState.S1
    assert r.new_ctx.s1_start_day == 0

def test_s0_stays_when_no_flag_or_acc_gt_cm():
    r1 = step_freeze(ctx(FreezeState.S0, now=0, flag=False, acc=1, cm=2))
    assert r1.new_ctx.state == FreezeState.S0 and r1.transition is None
    r2 = step_freeze(ctx(FreezeState.S0, now=0, flag=True, acc=3, cm=2))
    assert r2.new_ctx.state == FreezeState.S0 and r2.transition is None

def test_s1_disarms_to_s0_when_acc_gt_cm():
    r = step_freeze(ctx(FreezeState.S1, now=1, flag=True, acc=3, cm=2, s1=0))
    assert r.new_ctx.state == FreezeState.S0
    assert r.transition is not None and r.transition.from_state == FreezeState.S1 and r.transition.to_state == FreezeState.S0

def test_s1_cannot_exceed_14_days():
    with pytest.raises(RuntimeError):
        step_freeze(ctx(FreezeState.S1, now=S1_MAX_DAYS + 1, flag=True, acc=1, cm=2, s1=0))

def test_activate_s1_to_s2_sets_times():
    r = activate_freeze_from_s1(ctx(FreezeState.S1, now=10, flag=True, acc=1, cm=2, s1=0))
    assert r.new_ctx.state == FreezeState.S2
    assert r.new_ctx.s2_start_day == 10
    assert r.new_ctx.s2_hard_end_day == 10 + S2_MAX_DAYS
    assert r.new_ctx.next_review_due_day == 10 + REVIEW_CADENCE_DAYS

def test_s2_needs_review_when_due():
    c = ctx(FreezeState.S2, now=50, flag=True, acc=1, cm=2, s1=0, s2=10, end=10+S2_MAX_DAYS, next_rev=50)
    r = step_freeze(c)
    assert r.needs_review is True

def test_lift_s2_requires_valid_review_and_acc_gt_cm():
    c = ctx(FreezeState.S2, now=60, flag=True, acc=3, cm=2, s1=0, s2=10, end=10+S2_MAX_DAYS, next_rev=50)
    r = lift_freeze_from_s2(c, review_valid=True)
    assert r.new_ctx.state == FreezeState.S0
    assert r.transition is not None and r.transition.from_state == FreezeState.S2 and r.transition.to_state == FreezeState.S0

def test_lift_s2_not_allowed_if_review_invalid():
    c = ctx(FreezeState.S2, now=60, flag=True, acc=3, cm=2, s1=0, s2=10, end=10+S2_MAX_DAYS, next_rev=50)
    r = lift_freeze_from_s2(c, review_valid=False)
    assert r.new_ctx.state == FreezeState.S2

def test_s2_hard_expiry_to_s3_then_s0():
    start = 0
    end = start + S2_MAX_DAYS
    c = ctx(FreezeState.S2, now=end, flag=True, acc=1, cm=2, s1=0, s2=start, end=end, next_rev=10)
    r1 = step_freeze(c)
    assert r1.new_ctx.state == FreezeState.S3
    r2 = step_freeze(r1.new_ctx)
    assert r2.new_ctx.state == FreezeState.S0

