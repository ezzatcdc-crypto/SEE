import pytest

from emte_core.core.gate_engine import gate_from_freeze_state, GateState
from emte_core.core.freeze_engine import FreezeState


def test_gate_mapping_s0_open():
    d = gate_from_freeze_state(FreezeState.S0)
    assert d.gate_state == GateState.G0
    assert d.execution_allowed is True


def test_gate_mapping_s1_release_pending():
    d = gate_from_freeze_state(FreezeState.S1)
    assert d.gate_state == GateState.G2
    assert d.execution_allowed is False


def test_gate_mapping_s2_held():
    d = gate_from_freeze_state(FreezeState.S2)
    assert d.gate_state == GateState.G1
    assert d.execution_allowed is False


def test_gate_rejects_s3():
    with pytest.raises(RuntimeError):
        gate_from_freeze_state(FreezeState.S3)

