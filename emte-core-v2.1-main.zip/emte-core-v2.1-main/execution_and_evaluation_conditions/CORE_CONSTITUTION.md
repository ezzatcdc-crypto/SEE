# EMTE v2.1 — CORE CONSTITUTION
© EMTE Project – Governance Core Specification – All rights reserved.

## 0. Status
This document is **binding** for execution and evaluation of EMTE v2.1 Digital Core.
Any implementation that diverges from this document is **invalid for operation or evaluation**.

Repository path (required in every version):
`/execution_and_evaluation_conditions/CORE_CONSTITUTION.md`

---

## 1. Locked Architecture (Do Not Redefine)
These core definitions are fixed:

- **Energy = Flow**
- **Signal = System DNA**
- **Nexus = Flow + Signal + Measurement**
- **SEDV = Social–Ecological Descent Velocity**
- **TAR = Technology Absorption Rate**
- **Critical Mass = 50% + 1 Functional Capacity**
- **Voice = Contribution at Threshold Crossing**
- **Resilience = Adaptive Flow Stability**

---

## 2. Structural Conditions (Fixed)
A valid threshold crossing requires ALL of the following:

- Resource Mass
- Agreement Mass
- Acceleration > Collapse Momentum
- TAR present
- SEDV declining (baseline model)
- Contribution-based voice

### EQP v1.0 (Fixed)
- Integrated — Non-Override — Non-Upgrading

### Regional modifier (Fixed)
- Allowed ±15%
- Scenario-level only
- No proposal-level weight modification

---

## 3. SEDV Digital Model (Fixed)
- Baseline dt = 12 months
- Emergency dt = 6 months (Early Warning only)
- Environment axis priority = 0.50 weight
- Cut Rules apply **before** score

---

## 4. Emergency SEDV Governance (Routing Only)
Emergency SEDV (6m) **never overrides** baseline eligibility.
It is used only for:
- Risk flagging
- Freeze lifecycle routing
- Escalation triggering (non-decisional)

### 4.1 Emergency Flag (6m) — Activation/Deactivation
EmergencySEDV.flag is TRUE iff:
- ΔSEDV_6m < 0
- and |ΔSEDV_6m| ≥ EW_BAND_ON

EmergencySEDV.flag turns OFF iff:
- |ΔSEDV_6m| ≤ EW_BAND_OFF
- with EW_BAND_OFF = 0.8 × EW_BAND_ON (global fixed ratio)

EW_BAND may be modified only:
- Region/scenario level
- within ±15%
- never proposal-level

---

## 5. Freeze Lifecycle (S0–S3)
Freeze states:
- S0 = Inactive
- S1 = Armed (verification window)
- S2 = Active Freeze (execution hold)
- S3 = Expired marker

### 5.1 Entry Conditions
- S0 → S1 only if:
  - EmergencySEDV.flag = TRUE
  - Acceleration ≤ Collapse Momentum

### 5.2 S1 Constraints
- S1 max duration = 14 days
- S1 → S0 if Acceleration > Collapse Momentum
- S1 → S2 only by explicit activation decision while Acceleration ≤ Collapse Momentum

### 5.3 S2 Constraints
- S2 hard duration = 6 months (immutable)
- Review cadence ≤ 6 weeks
- Early lift allowed only at a valid Review Point when:
  - data density is sufficient
  - AND Acceleration > Collapse Momentum
- Hard expiry:
  - S2 → S3 when hard end reached
  - S3 → S0 immediately next step

### 5.4 Anti-Rolling
No rolling or stacking freeze windows are permitted for the same emergency window.

---

## 6. Freeze ↔ Escalation Contract (Non-Override)
Escalation is measurement support only.

- The only allowed escalation output is **StabilityAdvisorySignal**
- Freeze may consume only:
  - `data_density_status`
- Any advisory recommendations, weight changes, or decision instructions are forbidden.

---

## 7. Freeze ↔ Baseline Arbitration & Gate
Freeze suspends **execution only**. Measurement and eligibility evaluation may continue.

### 7.1 Gate States (G0–G2)
- G0 = Open
- G1 = Held
- G2 = Release Pending

### 7.2 Gate Mapping (Hard Invariant)
- S2 → G1 (Held)
- S1 → G2 (Release Pending)
- S0 → G0 (Open)

No threshold crossing execution is permitted unless Gate = G0.

### 7.3 Deferred Crossing Candidate
During S2, if threshold eligibility becomes ALL TRUE:
- record/update a single DeferredCrossingCandidate (no queue)
- do not execute crossing

### 7.4 Release Pending Revalidate
Upon exiting S2 to S0 (early lift or expiry path):
- a Revalidate MUST occur in the same tick/transaction.
- If all criteria are TRUE → execute once.
- If any criteria fail → drop deferred candidate (if any).

---

## 8. SEDV Conflict Handling (Baseline 12m vs Emergency 6m)
If sign(ΔSEDV_12m) ≠ sign(ΔSEDV_6m):
- log conflict only
- no direct routing or decision from conflict itself

Conflict types:
- conflict_A: baseline declining, emergency non-negative → logging only
- conflict_B: baseline non-negative, emergency declining → may route only via EmergencySEDV.flag rules (never directly)

---

## 9. Event Schema Pack v2.1 (Binding)
All operational messages and logs must comply with the v2.1 Event Schema Pack:
- schema validation
- idempotency rules
- non-leak constraints
- no proposal/actor identifiers

(Reference: internal project spec, same repository, same version.)

---

## 10. Runtime Invariants Pack v2.1 (Binding)
Runtime assertions must enforce:
- no execution under S1/S2
- gate mapping correctness
- revalidate-on-release same tick
- single execution per tick
- single deferred candidate per freeze window
- no S2 extension, no missing reviews
- escalation non-override
- non-leak constraints

(Reference: internal project spec, same repository, same version.)

---

## 11. Test Matrix v2.1 (Acceptance)
The only acceptance criterion for a compliant implementation is:
- Passing the v2.1 Test Matrix
- With zero violations of critical invariants

Any implementation failing this is **not acceptable** for operation or evaluation.

---

