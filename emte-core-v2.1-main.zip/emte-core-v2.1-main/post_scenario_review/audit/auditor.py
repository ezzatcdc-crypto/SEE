from __future__ import annotations

from typing import Any, Dict, List


def run_basic_audit(manifest: Dict[str, Any]) -> Dict[str, Any]:
    """
    Phase 1: Basic non-decisional audit.
    - Validates presence of key fields (schema_version, scenario_id, artifacts)
    - Validates producer.digital_core_version exists
    Output is advisory-only and never affects runtime.
    """
    findings: List[Dict[str, Any]] = []

    def fail(fid: str, claim: str, notes: str) -> None:
        findings.append(
            {
                "id": fid,
                "severity": "FAIL",
                "claim": claim,
                "notes": notes,
            }
        )

    def warn(fid: str, claim: str, notes: str) -> None:
        findings.append(
            {
                "id": fid,
                "severity": "WARN",
                "claim": claim,
                "notes": notes,
            }
        )

    # Required top-level fields
    for k in ["schema_version", "scenario_id", "artifacts"]:
        if k not in manifest:
            fail("AUD-MANIFEST-001", f"manifest has required key: {k}", f"Missing '{k}' in manifest.json")

    producer = manifest.get("producer", {})
    if not isinstance(producer, dict):
        fail("AUD-MANIFEST-002", "producer is an object", "producer must be a JSON object")
        producer = {}

    if "digital_core_version" not in producer:
        warn(
            "AUD-PRODUCER-001",
            "producer.digital_core_version is present",
            "Missing digital_core_version; add it to manifest producer block",
        )

    # Artifacts sanity (advisory)
    artifacts = manifest.get("artifacts", {})
    if isinstance(artifacts, dict):
        if not artifacts:
            warn("AUD-ARTIFACTS-001", "artifacts list is not empty", "No artifacts declared (events/transitions/decisions)")
    else:
        fail("AUD-ARTIFACTS-002", "artifacts is an object", "artifacts must be a JSON object")

    overall = "PASS"
    if any(f["severity"] == "FAIL" for f in findings):
        overall = "FAIL"
    elif any(f["severity"] == "WARN" for f in findings):
        overall = "WARN"

    return {
        "schema_version": "AUDIT-1.0",
        "scenario_id": manifest.get("scenario_id", "unknown"),
        "overall_status": overall,
        "advisory_only": True,
        "non_override": True,
        "non_decisional": True,
        "non_upgrading": True,
        "findings": findings,
    }
