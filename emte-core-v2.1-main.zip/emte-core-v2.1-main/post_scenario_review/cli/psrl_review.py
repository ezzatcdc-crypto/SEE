from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any, Dict, List

from post_scenario_review.audit.auditor import run_basic_audit
from post_scenario_review.timeline.timeline_builder import build_timeline_min
from post_scenario_review.timeline.timeline_full_builder import build_timeline_full


def _read_ndjson(path: Path) -> List[Dict[str, Any]]:
    if not path.exists():
        return []
    rows: List[Dict[str, Any]] = []
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line:
            continue
        rows.append(json.loads(line))
    return rows


def main() -> int:
    parser = argparse.ArgumentParser(description="PSRL Phase 2B (audit + minimal + unified timeline)")
    parser.add_argument("--seb", required=True, help="Path to SEB folder")
    parser.add_argument("--out", default="review_outputs", help="Output directory")
    args = parser.parse_args()

    seb_dir = Path(args.seb).resolve()
    out_base = Path(args.out).resolve()

    manifest_path = seb_dir / "manifest.json"
    if not manifest_path.exists():
        print("manifest.json not found")
        return 1

    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))

    # Optional streams (if present)
    artifacts = manifest.get("artifacts", {})
    if not isinstance(artifacts, dict):
        artifacts = {}

    events = _read_ndjson(seb_dir / artifacts.get("events", "events.ndjson"))
    transitions = _read_ndjson(seb_dir / artifacts.get("transitions", "transitions.ndjson"))
    decisions = _read_ndjson(seb_dir / artifacts.get("decisions", "decisions.ndjson"))

    audit_pack = run_basic_audit(manifest)

    scenario_id = manifest.get("scenario_id", "unknown_scenario")
    out_dir = out_base / scenario_id
    out_dir.mkdir(parents=True, exist_ok=True)

    review_summary = {
        "schema_version": "PSRL-2B.0",
        "scenario_id": scenario_id,
        "note": "Phase 2B: basic audit + minimal timeline + unified sorted timeline",
        "advisory_only": True,
        "non_override": True,
        "non_decisional": True,
    }

    timeline_min = build_timeline_min(
        scenario_id=scenario_id,
        events=events,
        transitions=transitions,
        decisions=decisions,
    )

    timeline_rows, timeline_index = build_timeline_full(
        events=events,
        transitions=transitions,
        decisions=decisions,
    )

    (out_dir / "review_summary.json").write_text(
        json.dumps(review_summary, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    (out_dir / "audit_pack.json").write_text(
        json.dumps(audit_pack, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    (out_dir / "timeline_min.json").write_text(
        json.dumps(timeline_min, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    # timeline_full.ndjson (one JSON per line)
    nd = "\n".join(json.dumps(r, ensure_ascii=False) for r in timeline_rows)
    if nd:
        nd += "\n"
    (out_dir / "timeline_full.ndjson").write_text(nd, encoding="utf-8")

    # timeline_index.json
    (out_dir / "timeline_index.json").write_text(
        json.dumps(timeline_index, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    print(f"PSRL outputs written to: {out_dir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
