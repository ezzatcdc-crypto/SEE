from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Dict, List, Optional


def _parse_ts(v: Any) -> Optional[datetime]:
    if v is None:
        return None
    # Accept ISO strings or numeric seconds
    if isinstance(v, (int, float)):
        try:
            return datetime.fromtimestamp(float(v), tz=timezone.utc)
        except Exception:
            return None
    if isinstance(v, str):
        s = v.strip()
        if not s:
            return None
        # tolerate trailing Z
        if s.endswith("Z"):
            s = s[:-1] + "+00:00"
        try:
            dt = datetime.fromisoformat(s)
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            return dt
        except Exception:
            return None
    return None


def _extract_any_timestamp(row: Dict[str, Any]) -> Optional[datetime]:
    # Try common keys in order
    for k in ["ts", "timestamp", "time", "created_at", "at"]:
        if k in row:
            dt = _parse_ts(row.get(k))
            if dt is not None:
                return dt
    return None


def build_timeline_min(
    scenario_id: str,
    events: List[Dict[str, Any]],
    transitions: List[Dict[str, Any]],
    decisions: List[Dict[str, Any]],
) -> Dict[str, Any]:
    """
    Minimal timeline: count + time bounds only.
    Non-decisional, advisory-only.
    """
    all_ts: List[datetime] = []

    for row in events:
        dt = _extract_any_timestamp(row)
        if dt is not None:
            all_ts.append(dt)

    for row in transitions:
        dt = _extract_any_timestamp(row)
        if dt is not None:
            all_ts.append(dt)

    for row in decisions:
        dt = _extract_any_timestamp(row)
        if dt is not None:
            all_ts.append(dt)

    first_ts = min(all_ts).astimezone(timezone.utc).isoformat().replace("+00:00", "Z") if all_ts else None
    last_ts = max(all_ts).astimezone(timezone.utc).isoformat().replace("+00:00", "Z") if all_ts else None

    duration_seconds = None
    if all_ts:
        duration_seconds = int((max(all_ts) - min(all_ts)).total_seconds())

    return {
        "schema_version": "TIMELINE-MIN-1.0",
        "scenario_id": scenario_id,
        "advisory_only": True,
        "non_override": True,
        "non_decisional": True,
        "counts": {
            "events": len(events),
            "transitions": len(transitions),
            "decisions": len(decisions),
        },
        "time_bounds": {
            "first_ts": first_ts,
            "last_ts": last_ts,
            "duration_seconds": duration_seconds,
        },
        "notes": [
            "Minimal timeline only (counts + time bounds).",
            "No interpretation. No feedback into runtime.",
        ],
    }


{"ts":"2026-02-12T10:05:10Z","from":"G0","to":"G1"}
{"ts":"2026-02-12T10:18:40Z","from":"S0","to":"S1"}
