from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Dict, Iterable, List, Optional, Tuple


def _parse_ts(v: Any) -> Optional[datetime]:
    if v is None:
        return None
    if isinstance(v, (int, float)):
        try:
            return datetime.fromtimestamp(float(v), tz=timezone.utc)
        except Exception:
            return None
    if isinstance(v, str):
        s = v.strip()
        if not s:
            return None
        if s.endswith("Z"):
            s = s[:-1] + "+00:00"
        try:
            dt = datetime.fromisoformat(s)
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            return dt.astimezone(timezone.utc)
        except Exception:
            return None
    return None


def _extract_ts(row: Dict[str, Any]) -> Optional[datetime]:
    for k in ["ts", "timestamp", "time", "created_at", "at"]:
        if k in row:
            dt = _parse_ts(row.get(k))
            if dt is not None:
                return dt
    return None


def _iso(dt: datetime) -> str:
    return dt.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


def _norm(kind: str, row: Dict[str, Any], seq: int) -> Dict[str, Any]:
    dt = _extract_ts(row)
    return {
        "seq": seq,
        "kind": kind,                  # event | transition | decision
        "ts": _iso(dt) if dt else None,
        "type": row.get("type") or row.get("name") or row.get("event") or None,
        "data": row,                   # raw row (no interpretation)
    }


def build_timeline_full(
    events: List[Dict[str, Any]],
    transitions: List[Dict[str, Any]],
    decisions: List[Dict[str, Any]],
) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    """
    Phase 2B: Unified, sorted timeline.
    Returns (rows_sorted, index).
    """
    rows: List[Dict[str, Any]] = []
    seq = 0

    for r in events:
        seq += 1
        rows.append(_norm("event", r, seq))

    for r in transitions:
        seq += 1
        rows.append(_norm("transition", r, seq))

    for r in decisions:
        seq += 1
        rows.append(_norm("decision", r, seq))

    def sort_key(x: Dict[str, Any]) -> Tuple[int, int]:
        # Put items with ts first; keep stable ordering by seq
        return (0 if x["ts"] else 1, x["seq"])

    # If both have timestamps, sort by timestamp then seq
    def sort_key2(x: Dict[str, Any]) -> Tuple[int, str, int]:
        return (0 if x["ts"] else 1, x["ts"] or "", x["seq"])

    rows_sorted = sorted(rows, key=sort_key2)

    # Index
    ts_vals = [r["ts"] for r in rows_sorted if r["ts"]]
    first_ts = ts_vals[0] if ts_vals else None
    last_ts = ts_vals[-1] if ts_vals else None

    type_counts: Dict[str, int] = {}
    for r in rows_sorted:
        t = r["type"] or "unknown"
        type_counts[t] = type_counts.get(t, 0) + 1

    index = {
        "schema_version": "TIMELINE-INDEX-1.0",
        "advisory_only": True,
        "non_override": True,
        "non_decisional": True,
        "counts": {
            "total": len(rows_sorted),
            "events": len(events),
            "transitions": len(transitions),
            "decisions": len(decisions),
        },
        "time_bounds": {"first_ts": first_ts, "last_ts": last_ts},
        "type_counts": type_counts,
        "notes": [
            "Unified sorted timeline (no interpretation).",
            "Rows keep raw payload under data.",
        ],
    }

    return rows_sorted, index
