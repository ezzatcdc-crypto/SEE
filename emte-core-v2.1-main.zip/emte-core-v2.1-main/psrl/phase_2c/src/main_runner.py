#!/usr/bin/env python3
# PSRL Phase 2C — Steps 0,1,2,3 (Read-only)
# Step 0: Manifest hashing (non-interference)
# Step 1: Frequency mapping (kind/type) — best-effort
# Step 2: Temporal density (bucket counts + bursts + gaps) — deterministic
# Step 3: Drift windows (median ratio vs baseline) — deterministic, separate artifact
#
# Inputs (read-only):
#   review_summary.json
#   audit_pack.json
#   timeline_min.json
#   timeline_full.ndjson
#   timeline_index.json
#
# Outputs (JSON):
#   phase_2c_manifest.json
#   patterns_frequency.json
#   patterns_density.json
#   patterns_drift.json
#   advisory_flags.json
#
# Non-interference:
# - No ML, no scoring changes, no runtime feedback loop.
# - Only consumes PSRL artifacts and emits advisory JSON.

from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
from datetime import datetime, timezone, timedelta
from typing import Any, Dict, Iterable, List, Optional, Tuple


# ---------------------------
# Utilities
# ---------------------------

def iso_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def sha256_file(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def ensure_dir(path: str) -> None:
    os.makedirs(path, exist_ok=True)


def read_json(path: str) -> Any:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def write_json(path: str, obj: Any) -> None:
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)


def iter_ndjson(path: str) -> Iterable[Tuple[int, Dict[str, Any]]]:
    with open(path, "r", encoding="utf-8") as f:
        for line_no, line in enumerate(f, start=1):
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
            except json.JSONDecodeError as e:
                raise ValueError(f"NDJSON parse error at line {line_no}: {e}") from e
            if isinstance(obj, dict):
                yield line_no, obj


def bump_count(counts: Dict[str, int], key: Optional[str], inc: int = 1) -> None:
    if key is None:
        return
    k = str(key).strip()
    if not k:
        return
    counts[k] = counts.get(k, 0) + inc


def top_k_items(counts: Dict[str, int], k: int) -> List[Dict[str, Any]]:
    return sorted(
        [{"key": kk, "count": vv} for kk, vv in counts.items()],
        key=lambda x: (-x["count"], x["key"])
    )[:k]


# ---------------------------
# Timeline TS parsing (matches your Phase 2B build)
# ---------------------------

def _parse_ts(v: Any) -> Optional[datetime]:
    if v is None:
        return None
    if isinstance(v, (int, float)):
        try:
            return datetime.fromtimestamp(float(v), tz=timezone.utc)
        except Exception:
            return None
    if isinstance(v, str):
        s = v.strip()
        if not s:
            return None
        if s.endswith("Z"):
            s = s[:-1] + "+00:00"
        try:
            dt = datetime.fromisoformat(s)
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            return dt.astimezone(timezone.utc)
        except Exception:
            return None
    return None


def extract_ts(row: Dict[str, Any]) -> Optional[datetime]:
    # Unified rows typically have "ts"; keep fallbacks.
    for k in ["ts", "timestamp", "time", "created_at", "at"]:
        if k in row:
            dt = _parse_ts(row.get(k))
            if dt is not None:
                return dt
    return None


def iso_z(dt: datetime) -> str:
    return dt.astimezone(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


# ---------------------------
# Step 2: Density helpers
# ---------------------------

def bucket_start(dt: datetime, bucket: str) -> datetime:
    dt = dt.astimezone(timezone.utc)
    if bucket == "hour":
        return dt.replace(minute=0, second=0, microsecond=0)
    if bucket == "day":
        return dt.replace(hour=0, minute=0, second=0, microsecond=0)
    if bucket == "week":
        # ISO week start = Monday
        start = dt.replace(hour=0, minute=0, second=0, microsecond=0)
        return start - timedelta(days=start.weekday())
    raise ValueError(f"Unsupported bucket: {bucket}")


def bucket_step(bucket: str) -> timedelta:
    if bucket == "hour":
        return timedelta(hours=1)
    if bucket == "day":
        return timedelta(days=1)
    if bucket == "week":
        return timedelta(days=7)
    raise ValueError(f"Unsupported bucket: {bucket}")


def rolling_median(values: List[int]) -> float:
    if not values:
        return 0.0
    s = sorted(values)
    n = len(s)
    mid = n // 2
    if n % 2 == 1:
        return float(s[mid])
    return (s[mid - 1] + s[mid]) / 2.0


def build_dense_series(
    counts_by_bucket: Dict[datetime, int],
    start: datetime,
    end: datetime,
    bucket: str
) -> List[Dict[str, Any]]:
    step = bucket_step(bucket)
    cur = start
    out: List[Dict[str, Any]] = []
    while cur <= end:
        out.append({"bucket_start": iso_z(cur), "event_count": int(counts_by_bucket.get(cur, 0))})
        cur += step
    return out


def find_gaps(series: List[Dict[str, Any]], min_gap_buckets: int = 2) -> List[Dict[str, Any]]:
    gaps: List[Dict[str, Any]] = []
    run_start: Optional[int] = None
    run_len = 0

    def flush(start_i: int, end_i: int) -> None:
        gaps.append({
            "start": series[start_i]["bucket_start"],
            "end": series[end_i]["bucket_start"],
            "bucket_count": (end_i - start_i + 1),
            "event_count": 0
        })

    for i, b in enumerate(series):
        if int(b["event_count"]) == 0:
            if run_start is None:
                run_start = i
                run_len = 1
            else:
                run_len += 1
        else:
            if run_start is not None and run_len >= min_gap_buckets:
                flush(run_start, i - 1)
            run_start = None
            run_len = 0

    if run_start is not None and run_len >= min_gap_buckets:
        flush(run_start, len(series) - 1)

    return gaps


def find_bursts(
    series: List[Dict[str, Any]],
    window: int = 14,
    multiplier: float = 3.0,
    min_burst_buckets: int = 2
) -> List[Dict[str, Any]]:
    """
    Deterministic burst detection:
    - baseline = rolling median of previous `window` buckets (excluding current)
    - burst bucket if count >= max(1, baseline * multiplier)
    - burst = consecutive run length >= min_burst_buckets
    """
    counts = [int(x["event_count"]) for x in series]
    bursts: List[Dict[str, Any]] = []
    burst_start: Optional[int] = None

    def baseline_at(i: int) -> float:
        prev = counts[max(0, i - window):i]
        return rolling_median(prev)

    for i in range(len(counts)):
        base = baseline_at(i)
        thresh = max(1.0, base * multiplier)
        is_burst = (counts[i] >= thresh) and (counts[i] > 0)

        if is_burst:
            if burst_start is None:
                burst_start = i
        else:
            if burst_start is not None:
                run_len = i - burst_start
                if run_len >= min_burst_buckets:
                    obs = sum(counts[burst_start:i])
                    base0 = rolling_median(counts[max(0, burst_start - window):burst_start])
                    bl = float(base0) * float(run_len)
                    bursts.append({
                        "start": series[burst_start]["bucket_start"],
                        "end": series[i - 1]["bucket_start"],
                        "bucket_count": run_len,
                        "baseline_method": "rolling_median",
                        "baseline_window_buckets": window,
                        "deviation": {"observed": int(obs), "baseline": float(bl)},
                        "multiplier": multiplier
                    })
                burst_start = None

    if burst_start is not None:
        run_len = len(counts) - burst_start
        if run_len >= min_burst_buckets:
            obs = sum(counts[burst_start:])
            base0 = rolling_median(counts[max(0, burst_start - window):burst_start])
            bl = float(base0) * float(run_len)
            bursts.append({
                "start": series[burst_start]["bucket_start"],
                "end": series[-1]["bucket_start"],
                "bucket_count": run_len,
                "baseline_method": "rolling_median",
                "baseline_window_buckets": window,
                "deviation": {"observed": int(obs), "baseline": float(bl)},
                "multiplier": multiplier
            })

    return bursts


# ---------------------------
# Step 3: Drift helpers
# ---------------------------

def _median_int(values: List[int]) -> float:
    if not values:
        return 0.0
    s = sorted(values)
    n = len(s)
    mid = n // 2
    if n % 2 == 1:
        return float(s[mid])
    return (s[mid - 1] + s[mid]) / 2.0


def compute_drift_windows(
    series: List[Dict[str, Any]],
    baseline_window: int = 28,
    drift_window: int = 14,
    drift_multiplier: float = 2.0,
    min_drift_windows: int = 2,
) -> Dict[str, Any]:
    """
    Deterministic drift:
    - baseline_median = median of counts in the previous baseline_window buckets (excluding current window).
    - window_median   = median of counts in the current drift_window buckets.
    - up_drift if window_median >= max(1, baseline_median * drift_multiplier)
    - down_drift if baseline_median >= max(1, window_median * drift_multiplier)
    - drift run = consecutive windows meeting condition >= min_drift_windows
    """
    counts = [int(x.get("event_count", 0)) for x in series]
    n = len(counts)
    if n == 0:
        return {"up_drifts": [], "down_drifts": [], "windows": []}

    windows: List[Dict[str, Any]] = []

    for end_i in range(drift_window - 1, n):
        win_start = end_i - drift_window + 1
        win_counts = counts[win_start:end_i + 1]

        base_end = win_start
        base_start = max(0, base_end - baseline_window)
        base_counts = counts[base_start:base_end]

        baseline_med = _median_int(base_counts)
        window_med = _median_int(win_counts)

        up_thresh = max(1.0, baseline_med * drift_multiplier)
        down_thresh = max(1.0, window_med * drift_multiplier)

        is_up = (window_med >= up_thresh) and (window_med > 0)
        is_down = (baseline_med >= down_thresh) and (baseline_med > 0)

        windows.append({
            "window_start": series[win_start]["bucket_start"],
            "window_end": series[end_i]["bucket_start"],
            "window_median": window_med,
            "baseline_median": baseline_med,
            "up_threshold": up_thresh,
            "down_threshold": down_thresh,
            "is_up_drift": bool(is_up),
            "is_down_drift": bool(is_down),
        })

    def _collapse_runs(flag_key: str) -> List[Dict[str, Any]]:
        runs: List[Dict[str, Any]] = []
        run_start: Optional[int] = None

        def flush(a: int, b: int) -> None:
            length = b - a + 1
            if length < min_drift_windows:
                return
            seg = windows[a:b + 1]
            runs.append({
                "start": seg[0]["window_start"],
                "end": seg[-1]["window_end"],
                "window_count": length,
                "baseline_median": seg[0]["baseline_median"],
                "window_median_start": seg[0]["window_median"],
                "window_median_end": seg[-1]["window_median"],
                "multiplier": drift_multiplier,
            })

        for i, w in enumerate(windows):
            ok = bool(w.get(flag_key, False))
            if ok:
                if run_start is None:
                    run_start = i
            else:
                if run_start is not None:
                    flush(run_start, i - 1)
                    run_start = None

        if run_start is not None:
            flush(run_start, len(windows) - 1)

        return runs

    up_drifts = _collapse_runs("is_up_drift")
    down_drifts = _collapse_runs("is_down_drift")

    return {"up_drifts": up_drifts, "down_drifts": down_drifts, "windows": windows}


# ---------------------------
# Main
# ---------------------------

def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--inputs-dir", required=True)
    ap.add_argument("--outputs-dir", required=True)
    ap.add_argument("--top-k", type=int, default=20)

    # Step 2 params
    ap.add_argument("--bucket", choices=["hour", "day", "week"], default="day")
    ap.add_argument("--density-window", type=int, default=14)
    ap.add_argument("--density-multiplier", type=float, default=3.0)
    ap.add_argument("--min-gap-buckets", type=int, default=2)
    ap.add_argument("--min-burst-buckets", type=int, default=2)

    # Step 3 params (Drift)
    ap.add_argument("--baseline-window", type=int, default=28)
    ap.add_argument("--drift-window", type=int, default=14)
    ap.add_argument("--drift-multiplier", type=float, default=2.0)
    ap.add_argument("--min-drift-windows", type=int, default=2)

    args = ap.parse_args()

    inputs = {
        "review_summary": os.path.join(args.inputs_dir, "review_summary.json"),
        "audit_pack": os.path.join(args.inputs_dir, "audit_pack.json"),
        "timeline_min": os.path.join(args.inputs_dir, "timeline_min.json"),
        "timeline_full": os.path.join(args.inputs_dir, "timeline_full.ndjson"),
        "timeline_index": os.path.join(args.inputs_dir, "timeline_index.json"),
    }

    missing = [p for p in inputs.values() if not os.path.exists(p)]
    if missing:
        print("Missing required inputs:", file=sys.stderr)
        for m in missing:
            print(" -", m, file=sys.stderr)
        sys.exit(2)

    started = iso_now()
    ensure_dir(args.outputs_dir)

    # Step 0 — Hash inputs
    input_hashes: List[Dict[str, str]] = []
    for name, path in inputs.items():
        input_hashes.append({"name": name, "file": os.path.basename(path), "sha256": sha256_file(path)})

    # Step 1 — Frequency mapping (kind + type)
    by_kind: Dict[str, int] = {}
    by_type: Dict[str, int] = {}
    total_rows = 0
    sample_seq: List[int] = []

    first_ts_raw: Optional[str] = None
    last_ts_raw: Optional[str] = None

    for _, raw in iter_ndjson(inputs["timeline_full"]):
        total_rows += 1
        bump_count(by_kind, raw.get("kind"))
        bump_count(by_type, raw.get("type"))

        ts_val = raw.get("ts")
        if isinstance(ts_val, str) and ts_val.strip():
            if first_ts_raw is None:
                first_ts_raw = ts_val
            last_ts_raw = ts_val

        seq = raw.get("seq")
        if isinstance(seq, int) and len(sample_seq) < 25:
            sample_seq.append(seq)

    patterns_frequency = {
        "psrl": {"layer": "2C", "name": "frequency_map", "version": "2.1.0"},
        "window": {"start": first_ts_raw, "end": last_ts_raw, "bucket": "none"},
        "counts": {
            "by_kind": top_k_items(by_kind, args.top_k),
            "by_type": top_k_items(by_type, args.top_k),
        },
        "meta": {"total_rows": total_rows},
        "evidence": {
            "sample_seq": sample_seq,
            "notes": ["Descriptive only. No scoring. No thresholds. No runtime feedback."]
        }
    }

    # Step 2 — Temporal density (bucket series + gaps + bursts)
    counts_by_bucket: Dict[datetime, int] = {}
    first_dt: Optional[datetime] = None
    last_dt: Optional[datetime] = None

    for _, raw in iter_ndjson(inputs["timeline_full"]):
        dt = extract_ts(raw)
        if dt is None:
            continue
        if first_dt is None:
            first_dt = dt
        last_dt = dt
        b0 = bucket_start(dt, args.bucket)
        counts_by_bucket[b0] = counts_by_bucket.get(b0, 0) + 1

    patterns_density: Dict[str, Any] = {
        "psrl": {"layer": "2C", "name": "temporal_density", "version": "2.1.0"},
        "bucket": args.bucket,
        "series": [],
        "gaps": [],
        "bursts": [],
        "meta": {
            "total_rows": total_rows,
            "time_bounds": {
                "first_ts": iso_z(first_dt) if first_dt else None,
                "last_ts": iso_z(last_dt) if last_dt else None,
            }
        },
        "method": {
            "baseline": "rolling_median",
            "window_buckets": args.density_window,
            "multiplier": args.density_multiplier,
            "min_gap_buckets": args.min_gap_buckets,
            "min_burst_buckets": args.min_burst_buckets,
        },
        "notes": [
            "Descriptive density only. No scoring. No thresholds. No runtime feedback."
        ],
        "evidence": {"sample_seq": sample_seq}
    }

    if first_dt and last_dt:
        s0 = bucket_start(first_dt, args.bucket)
        e0 = bucket_start(last_dt, args.bucket)
        series = build_dense_series(counts_by_bucket, s0, e0, args.bucket)
        patterns_density["series"] = series
        patterns_density["gaps"] = find_gaps(series, min_gap_buckets=args.min_gap_buckets)
        patterns_density["bursts"] = find_bursts(
            series,
            window=args.density_window,
            multiplier=args.density_multiplier,
            min_burst_buckets=args.min_burst_buckets
        )

    # Step 3 — Drift (separate artifact)
    patterns_drift: Dict[str, Any] = {
        "psrl": {"layer": "2C", "name": "temporal_drift", "version": "2.1.0"},
        "bucket": args.bucket,
        "meta": patterns_density["meta"],
        "method": {
            "baseline": "median",
            "baseline_window_buckets": args.baseline_window,
            "drift_window_buckets": args.drift_window,
            "multiplier": args.drift_multiplier,
            "min_drift_windows": args.min_drift_windows,
        },
        "results": {"up_drifts": [], "down_drifts": [], "windows": []},
        "notes": [
            "Descriptive drift only. No scoring. No runtime feedback.",
            "Derived from patterns_density.series only."
        ],
        "evidence": {"sample_seq": sample_seq}
    }

    if patterns_density.get("series"):
        drift_res = compute_drift_windows(
            patterns_density["series"],
            baseline_window=args.baseline_window,
            drift_window=args.drift_window,
            drift_multiplier=args.drift_multiplier,
            min_drift_windows=args.min_drift_windows,
        )
        patterns_drift["results"] = drift_res

    # Advisory flags (advisory-only)
    flags: List[Dict[str, Any]] = []

    def mk_flag(flag_id: str, category: str, title: str, statement: str, ref: str) -> Dict[str, Any]:
        return {
            "flag_id": flag_id,
            "category": category,
            "title": title,
            "statement": statement,
            "window": patterns_density["meta"]["time_bounds"],
            "evidence": {
                "source_artifacts": ["timeline_full.ndjson"],
                "seq": sample_seq[:10],
                "pattern_ref": ref
            },
            "non_interference": {
                "advisory_only": True,
                "no_runtime_feedback": True,
                "no_threshold_modification": True
            }
        }

    if patterns_frequency["counts"]["by_kind"]:
        top = patterns_frequency["counts"]["by_kind"][0]
        flags.append(mk_flag(
            "FREQ-KIND-001",
            "frequency",
            "Most frequent row kind",
            f"Kind '{top['key']}' appears {top['count']} times.",
            "patterns_frequency.json#/counts/by_kind/0"
        ))

    if patterns_density["gaps"]:
        g0 = patterns_density["gaps"][0]
        flags.append(mk_flag(
            "DENS-GAP-001",
            "density",
            "Gap window detected",
            f"Gap from {g0['start']} to {g0['end']} spanning {g0['bucket_count']} buckets with 0 events.",
            "patterns_density.json#/gaps/0"
        ))

    if patterns_density["bursts"]:
        b0 = patterns_density["bursts"][0]
        flags.append(mk_flag(
            "DENS-BURST-001",
            "density",
            "Burst window detected",
            f"Burst from {b0['start']} to {b0['end']} spanning {b0['bucket_count']} buckets (multiplier={b0['multiplier']}).",
            "patterns_density.json#/bursts/0"
        ))

    # Drift flags (optional but useful)
    if patterns_drift["results"].get("up_drifts"):
        d0 = patterns_drift["results"]["up_drifts"][0]
        flags.append(mk_flag(
            "DRIFT-UP-001",
            "drift",
            "Upward drift detected",
            f"Up-drift from {d0['start']} to {d0['end']} spanning {d0['window_count']} windows (multiplier={d0['multiplier']}).",
            "patterns_drift.json#/results/up_drifts/0"
        ))

    if patterns_drift["results"].get("down_drifts"):
        d0 = patterns_drift["results"]["down_drifts"][0]
        flags.append(mk_flag(
            "DRIFT-DOWN-001",
            "drift",
            "Downward drift detected",
            f"Down-drift from {d0['start']} to {d0['end']} spanning {d0['window_count']} windows (multiplier={d0['multiplier']}).",
            "patterns_drift.json#/results/down_drifts/0"
        ))

    advisory_flags = {
        "psrl": {"layer": "2C", "name": "advisory_flags", "version": "2.1.0"},
        "flags": flags
    }

    # Write outputs
    out_freq = os.path.join(args.outputs_dir, "patterns_frequency.json")
    out_density = os.path.join(args.outputs_dir, "patterns_density.json")
    out_drift = os.path.join(args.outputs_dir, "patterns_drift.json")
    out_flags = os.path.join(args.outputs_dir, "advisory_flags.json")
    out_manifest = os.path.join(args.outputs_dir, "phase_2c_manifest.json")

    write_json(out_freq, patterns_frequency)
    write_json(out_density, patterns_density)
    write_json(out_drift, patterns_drift)
    write_json(out_flags, advisory_flags)

    completed = iso_now()

    outputs = [
        {"file": "patterns_frequency.json", "sha256": sha256_file(out_freq)},
        {"file": "patterns_density.json", "sha256": sha256_file(out_density)},
        {"file": "patterns_drift.json", "sha256": sha256_file(out_drift)},
        {"file": "advisory_flags.json", "sha256": sha256_file(out_flags)},
    ]

    manifest = {
        "psrl": {"layer": "2C", "version": "2.1.0"},
        "inputs": [{"file": x["file"], "sha256": x["sha256"]} for x in input_hashes],
        "outputs": outputs,
        "config": {
            "top_k": args.top_k,
            "bucket": args.bucket,
            "density_window": args.density_window,
            "density_multiplier": args.density_multiplier,
            "min_gap_buckets": args.min_gap_buckets,
            "min_burst_buckets": args.min_burst_buckets,
            "baseline_window": args.baseline_window,
            "drift_window": args.drift_window,
            "drift_multiplier": args.drift_multiplier,
            "min_drift_windows": args.min_drift_windows
        },
        "run": {"started_at": started, "completed_at": completed, "deterministic": True},
        "non_interference": {
            "read_only_inputs": True,
            "no_runtime_feedback": True,
            "no_threshold_modification": True
        }
    }

    write_json(out_manifest, manifest)

    print("OK")
    print("Wrote:", out_manifest)
    print("Wrote:", out_freq)
    print("Wrote:", out_density)
    print("Wrote:", out_drift)
    print("Wrote:", out_flags)


if __name__ == "__main__":
    main()
