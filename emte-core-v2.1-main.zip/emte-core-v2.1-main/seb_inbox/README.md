Drop SEB zip files here for manual PSRL runs.
