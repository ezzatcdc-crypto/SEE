# CORE Upgrade Proposal

## Upgrade Type
- [ ] Deterministic Patch
- [ ] Minor Capability Extension
- [ ] Major Semantic Change

## Change Summary
Describe the deterministic engine evolution and why it is required.

## Contract Updates
- [ ] vendor/emte-core gitlink updated
- [ ] emte_release.json updated
- [ ] governance/core_upgrade.yaml updated

## Determinism Impact
- [ ] No schema change
- [ ] Schema extended (backward compatible)
- [ ] Schema breaking change

## Risk Assessment
- Artifact drift expected? (Yes/No)
- Backward compatibility preserved? (Yes/No)

## Verification
- [ ] CI passes
- [ ] Review approvals ≥ 2
- [ ] No unrelated file changes

---

**Upgrade must only modify:**
- vendor/emte-core
- emte_release.json
- governance/core_upgrade.yaml
