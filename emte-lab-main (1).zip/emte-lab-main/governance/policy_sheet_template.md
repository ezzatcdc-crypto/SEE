# EMTE Policy Sheet — v1.0 (Eastern Mediterranean)
**Mode:** EMTE-level (regional implementation of ASE)  
**Status:** Template (renders from canonical artifacts once available)

---

## 0) Release Identity (Deterministic)
- LAB version: {{lab_version}}
- CORE version: {{core_version}}
- CORE SHA (gitlink): {{core_sha}}
- Run ID: {{run_id}}
- Timestamp (UTC): {{run_timestamp}}

**Canonical artifacts**
- run_manifest.json: {{path_run_manifest}}
- indicators.json: {{path_indicators}}
- patterns_drift.json: {{path_patterns_drift}}
- timeline.json: {{path_timeline}}
- data_snapshot.json: {{path_data_snapshot}}

---

## 1) Regional Scope Definition (EMTE Field)
**Region:** Eastern Mediterranean  
**Field frame:** {{field_frame_short}}
- Primary pressures: {{pressure_list}}
- Active cascades (if any): {{cascade_list}}
- Known thresholds (regional): {{threshold_list}}

> Note: EMTE applies ASE invariants; it does not redefine them.

---

## 2) System State Summary (Operational)
### 2.1 Stability Posture
- Stability index (if defined): {{stability_index}}
- Resilience posture: {{resilience_posture}}
- Integrity flags (Core Guard / audits): {{integrity_flags}}

### 2.2 Primary Findings (top 5)
1. {{finding_1}}
2. {{finding_2}}
3. {{finding_3}}
4. {{finding_4}}
5. {{finding_5}}

**Evidence pointers (artifact paths)**
- {{evidence_ptr_1}}
- {{evidence_ptr_2}}
- {{evidence_ptr_3}}

---

## 3) Governing Indicators (Measurable / Accountable)
> Governing values are operational and measurable. These indicators are bound to artifacts.

| Indicator | Current | Baseline | Trend | Threshold line | Confidence | Evidence |
|---|---:|---:|---|---|---|---|
| {{ind_1_name}} | {{ind_1_cur}} | {{ind_1_base}} | {{ind_1_trend}} | {{ind_1_line}} | {{ind_1_conf}} | {{ind_1_ev}} |
| {{ind_2_name}} | {{ind_2_cur}} | {{ind_2_base}} | {{ind_2_trend}} | {{ind_2_line}} | {{ind_2_conf}} | {{ind_2_ev}} |
| {{ind_3_name}} | {{ind_3_cur}} | {{ind_3_base}} | {{ind_3_trend}} | {{ind_3_line}} | {{ind_3_conf}} | {{ind_3_ev}} |
| {{ind_4_name}} | {{ind_4_cur}} | {{ind_4_base}} | {{ind_4_trend}} | {{ind_4_line}} | {{ind_4_conf}} | {{ind_4_ev}} |
| {{ind_5_name}} | {{ind_5_cur}} | {{ind_5_base}} | {{ind_5_trend}} | {{ind_5_line}} | {{ind_5_conf}} | {{ind_5_ev}} |

---

## 4) Threshold Lines (Regional)
### 4.1 Active Lines
- Line A: {{line_a_def}} → status: {{line_a_status}} → crossing risk: {{line_a_risk}}
- Line B: {{line_b_def}} → status: {{line_b_status}} → crossing risk: {{line_b_risk}}

### 4.2 Near-Term Crossings (0–90 days)
- {{near_cross_1}}
- {{near_cross_2}}
- {{near_cross_3}}

**Evidence:** {{lines_evidence_ptrs}}

---

## 5) Cascade & Resilience Dynamics (EMTE)
### 5.1 Cascade Signals (if any)
- Cascade signature: {{cascade_signature}}
- Stage: {{cascade_stage}}
- Propagation vectors: {{prop_vectors}}

### 5.2 Resilience Profile
- Resilience mode: {{res_mode}}
- Buffer status: {{buffer_status}}
- Recovery window estimate: {{recovery_window}}

**Evidence:** {{cascade_resilience_evidence}}

---

## 6) Cut-Rules Compliance (False-positive prevention)
> Cut-Rules are enforced to prevent category errors.

- تشغيل ≠ تحوّل: {{cut_operating_vs_transition}}
- إدارة ≠ خفض تفكك: {{cut_management_vs_decomposition}}
- صمود ≠ إعادة إنتاج: {{cut_resilience_vs_reproduction}}
- تعويض بيئي ≠ استقرار: {{cut_compensation_vs_stability}}

If any cut-rule is violated → policy output must be downgraded to **Advisory** and cannot be published as “governing”.

---

## 7) Response Options (Operational Menu)
> Responses are classified to prevent “policy cosplay” and preserve determinism.

### 7.1 Immediate Containment (0–30 days)
- R1: {{r1_action}}  
  - Type: {{r1_type}} (تشغيل / خفض تفكك / تحوّل)  
  - Expected effect: {{r1_effect}}  
  - Risk: {{r1_risk}}  
  - Trigger line: {{r1_trigger}}  
  - Evidence: {{r1_evidence}}

- R2: {{r2_action}} (same structure)

### 7.2 Stabilization (30–180 days)
- R3: {{r3_action}} (same structure)
- R4: {{r4_action}} (same structure)

### 7.3 Structural Shift (180–720 days)
- R5: {{r5_action}} (same structure)

---

## 8) Regional Subsidiarity Map (Who acts where)
- Local: {{subs_local}}
- National: {{subs_national}}
- Regional: {{subs_regional}}
- International: {{subs_international}}

---

## 9) Monitoring & Next Review
- Monitoring cadence: {{monitoring_cadence}}
- Next review trigger: {{next_review_trigger}}
- Minimum data needed: {{data_gaps_min}}

---

## 10) Confidence & Uncertainty Register
- Confidence score (0–1): {{confidence_score}}
- Key uncertainties:
  - U1: {{uncertainty_1}}
  - U2: {{uncertainty_2}}
- What would change the recommendation fastest:
  - {{sensitivity_1}}
  - {{sensitivity_2}}

---

## 11) Publication Mode
- [ ] Advisory (non-governing)
- [ ] Governing (requires cut-rule compliance + evidence completeness)
- [ ] Restricted (sensitive; internal only)

Selected mode: {{publication_mode}}

---

### Appendix: Artifact Pointers
- {{artifact_ptr_1}}
- {{artifact_ptr_2}}
- {{artifact_ptr_3}}
