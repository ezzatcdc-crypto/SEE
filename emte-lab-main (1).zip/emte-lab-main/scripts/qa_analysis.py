import json
import sys

def fail(msg):
    print(f"ANALYSIS QA FAIL: {msg}")
    sys.exit(1)

def load_pack(path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

def check_claims(pack):
    claims = pack.get("claims", [])
    evidence = pack.get("evidence_bullets", [])

    if len(claims) < 3:
        fail("Not enough claims (<3)")

    for i, c in enumerate(claims):
        ids = c.get("evidence_ids", [])
        if not ids:
            fail(f"Claim {i+1} missing evidence_ids")
        for eid in ids:
            if eid < 1 or eid > len(evidence):
                fail(f"Claim {i+1} references invalid evidence id {eid}")

def check_mechanisms(pack):
    mechs = pack.get("mechanisms", [])
    if len(mechs) < 2:
        fail("Not enough mechanisms (<2)")

    for m in mechs:
        if not all(k in m for k in ["if", "then", "because"]):
            fail(f"Mechanism {m.get('id')} incomplete")

def check_thresholds(pack):
    th = pack.get("thresholds", [])
    if len(th) < 3:
        fail("Not enough thresholds (<3)")

    for t in th:
        for k in ["indicator", "trigger_window", "effect"]:
            if k not in t:
                fail(f"Threshold {t.get('id')} missing {k}")

def check_scenarios(pack):
    sc = pack.get("scenarios", [])
    if len(sc) < 3:
        fail("Not enough scenarios (<3)")

    for s in sc:
        if "relative_likelihood" not in s or "description" not in s:
            fail(f"Scenario {s.get('id')} incomplete")

def check_confidence(pack):
    conf = pack.get("confidence", {})
    for k in ["depends_on", "uncertainties", "would_change_if"]:
        if k not in conf:
            fail(f"Confidence missing {k}")

def main():
    if len(sys.argv) != 2:
        print("Usage: qa_analysis.py <pack.json>")
        sys.exit(1)

    pack = load_pack(sys.argv[1])

    check_claims(pack)
    check_mechanisms(pack)
    check_thresholds(pack)
    check_scenarios(pack)
    check_confidence(pack)

    print("ANALYSIS QA PASS: pack contains decision-grade analysis")

if __name__ == "__main__":
    main()
