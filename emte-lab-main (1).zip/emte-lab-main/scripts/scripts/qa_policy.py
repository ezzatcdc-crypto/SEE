from __future__ import annotations

import argparse
import json
from pathlib import Path


def main() -> int:
    print("QA: started")

    parser = argparse.ArgumentParser()
    parser.add_argument("--pack", required=True)
    parser.add_argument("--out", required=True)
    args = parser.parse_args()

    pack_path = Path(args.pack)
    out_path = Path(args.out)

    print("Pack path:", pack_path.resolve())
    print("Output path:", out_path.resolve())

    if not pack_path.exists():
        print("FAIL: Context pack not found.")
        return 1
    if not out_path.exists():
        print("FAIL: Policy output not found.")
        return 1

    pack = json.loads(pack_path.read_text(encoding="utf-8"))
    text = out_path.read_text(encoding="utf-8")

    score = 100
    failures: list[str] = []

    # Depth gates (research structure)
    if len(pack.get("context_anchors", [])) < 5:
        failures.append("Too few context anchors (<5)")
        score -= 20
    if len(pack.get("evidence_bullets", [])) < 8:
        failures.append("Too few evidence bullets (<8)")
        score -= 20
    if len(pack.get("claims", [])) < 6:
        failures.append("Too few claims (<6)")
        score -= 20

    # Template contract
    required_sections = [
        "Executive Summary",
        "Threshold Watch",
        "Political Outlook (90 Days)",
        "Confidence Level",
    ]
    for sec in required_sections:
        if f"## {sec}" not in text:
            failures.append(f"Missing section: {sec}")
            score -= 10

    score = max(score, 0)
    print("\nQA SCORE:", score, "/100")

    if failures:
        print("\nFAILURES:")
        for f in failures:
            print("-", f)
        return 2

    print("PASS: Output meets quality gates.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
