from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List

OUTPUT_DIR = Path("policy_outputs")
INPUT_DIR = Path("policy_inputs")


def _load_pack(path: Path) -> Dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def _md_list(items: List[str]) -> str:
    return "\n".join([f"- {x}" for x in items])


def render_lebanon(pack: Dict[str, Any]) -> str:
    now = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    topic = pack.get("topic", "Lebanon Front Watch")
    region = pack.get("region", "Eastern Mediterranean")
    tw = int(pack.get("time_window_days", 90))
    actors = pack.get("actors", [])
    anchors = pack.get("context_anchors", [])
    evidence = pack.get("evidence_bullets", [])
    claims = pack.get("claims", [])

    title = "EMTE Regional Stability Report – Issue 02"
    subtitle = "Lebanon Front Watch: Controlled Escalation or Structural Drift?"

    md = f"""# {title}
## {subtitle}

- Generated: {now} (UTC)
- Region: {region}
- Time window: {tw} days

## Executive Summary
This is a LAB-grade policy brief generated from a structured context pack.
It prioritizes threshold conditions, actor calibration, and near-term escalation logic.

Key idea: containment may hold, but the system is sensitive to miscalculation triggers.

## Structural Status
**Actors:** {", ".join(actors) if actors else "N/A"}

**Context anchors:**
{_md_list(anchors) if anchors else "- N/A"}

## Threshold Watch
Below are threshold conditions to monitor. Any breach increases cascade probability.

**Evidence bullets:**
{_md_list(evidence) if evidence else "- N/A"}

## Political Outlook (90 Days)
Working assessment over {tw} days:

**Claims (with evidence pointers):**
"""
    if claims:
        for i, c in enumerate(claims, start=1):
            txt = str(c.get("text", "")).strip()
            eids = c.get("evidence_ids", [])
            md += f"\n{i}. {txt} (evidence: {eids})"
    else:
        md += "\n- N/A"

    # --- Mandatory template contract: Confidence Level ---
    if "## Confidence Level" not in md:
        md += "\n\n## Confidence Level\n**Medium** — bounded by limited verified inputs; primary uncertainty is miscalculation/trigger-event timing.\n"

    return md


def main() -> int:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    pack_path = INPUT_DIR / "lebanon_pack.json"
    if not pack_path.exists():
        raise SystemExit(f"Missing pack: {pack_path} (create policy_inputs/lebanon_pack.json)")

    pack = _load_pack(pack_path)

    out_path = OUTPUT_DIR / "EMTE-Issue-02-Lebanon.md"
    md = render_lebanon(pack)
    out_path.write_text(md, encoding="utf-8")
    print(f"Policy generated at: {out_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
