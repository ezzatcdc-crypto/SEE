from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List
import json


@dataclass(frozen=True)
class RegistryIndex:
    latest_run_id: str | None
    runs: List[Dict[str, Any]]  # append-only metadata


def _read_json(path: Path) -> Any:
    if not path.exists():
        return None
    return json.loads(path.read_text(encoding="utf-8"))


def _write_json(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, sort_keys=True, indent=2), encoding="utf-8")


def load_registry(registry_path: Path) -> RegistryIndex:
    obj = _read_json(registry_path)
    if not obj:
        return RegistryIndex(latest_run_id=None, runs=[])
    return RegistryIndex(latest_run_id=obj.get("latest_run_id"), runs=obj.get("runs", []))


def update_registry(registry_path: Path, run_meta: Dict[str, Any]) -> RegistryIndex:
    idx = load_registry(registry_path)
    runs = [*idx.runs, run_meta]
    obj = {"latest_run_id": run_meta["run_id"], "runs": runs}
    _write_json(registry_path, obj)
    return RegistryIndex(latest_run_id=run_meta["run_id"], runs=runs)
