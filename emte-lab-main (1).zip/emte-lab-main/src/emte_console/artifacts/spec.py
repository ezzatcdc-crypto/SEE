from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Literal, Mapping

ArtifactName = Literal[
    "run_manifest.json",
    "data_snapshot.json",
    "indicators.json",
    "patterns_drift.json",
    "timeline.json",
]


CANONICAL_ARTIFACTS: List[ArtifactName] = [
    "run_manifest.json",
    "data_snapshot.json",
    "indicators.json",
    "patterns_drift.json",
    "timeline.json",
]


@dataclass(frozen=True)
class RunManifest:
    run_id: str
    created_utc: str
    core_tag: str
    core_head: str
    lab_version: str
    inputs: Dict[str, Any]
    outputs: Dict[str, str]  # artifact name -> relative path


def validate_artifact_set(files: Mapping[str, bytes]) -> None:
    missing = [a for a in CANONICAL_ARTIFACTS if a not in files]
    if missing:
        raise ValueError(f"Missing canonical artifacts: {missing}")
