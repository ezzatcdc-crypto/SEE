from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any


def _canon_json(obj: Any) -> bytes:
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")


def sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def write_json(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(_canon_json(obj))


def json_hash(obj: Any) -> str:
    return sha256_hex(_canon_json(obj))


def build_run_id(created_utc_compact: str, core_tag: str, dataset_hash8: str, cfg_hash8: str) -> str:
    return f"{created_utc_compact}_{core_tag}_{dataset_hash8}_{cfg_hash8}"
