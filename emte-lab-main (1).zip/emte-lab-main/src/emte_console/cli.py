from __future__ import annotations

import argparse
from pathlib import Path
from datetime import datetime, timezone

from rich.console import Console
from rich.table import Table

from emte_console.core_guard import assert_core_frozen, CoreGuardError
from emte_console.artifacts.registry import load_registry
from emte_console.runner import run_emte

console = Console()

DEFAULT_CORE_PATH = Path("vendor/emte-core")
REQUIRED_CORE_TAG = "v2.1.0-core-frozen"
DEFAULT_OUTPUTS = Path("outputs")


def _utc_now() -> tuple[str, str]:
    dt = datetime.now(timezone.utc).replace(microsecond=0)
    iso = dt.isoformat().replace("+00:00", "Z")
    compact = dt.strftime("%Y%m%dT%H%M%SZ")
    return iso, compact


def cmd_verify_core(args: argparse.Namespace) -> int:
    try:
        st = assert_core_frozen(Path(args.core), REQUIRED_CORE_TAG)
        console.print("[green]OK[/green] core frozen", st.described_tag, st.head_commit)
        return 0
    except CoreGuardError as e:
        console.print("[red]FAIL[/red]", str(e))
        return 2


def cmd_registry(args: argparse.Namespace) -> int:
    idx = load_registry(Path(args.outputs) / "registry" / "index.json")
    console.print(f"Latest: {idx.latest_run_id}")
    t = Table("created_utc", "run_id")
    for r in idx.runs[-20:]:
        t.add_row(str(r.get("created_utc", "")), str(r.get("run_id", "")))
    console.print(t)
    return 0


def cmd_run(args: argparse.Namespace) -> int:
    created_iso, created_compact = _utc_now()

    # placeholder: you’ll wire real snapshot+core outputs here
    inputs = {"profile": args.profile, "baseline_window": args.baseline_window}
    data_snapshot = {"note": "placeholder snapshot", "profile": args.profile}
    indicators = {"note": "placeholder indicators"}
    patterns_drift = {"note": "placeholder drift"}
    timeline = {"note": "placeholder timeline"}

    res = run_emte(
        vendor_core_path=Path(args.core),
        required_core_tag=REQUIRED_CORE_TAG,
        outputs_root=Path(args.outputs),
        lab_version="2.1.0",
        created_utc=created_iso,
        created_utc_compact=created_compact,
        inputs=inputs,
        data_snapshot=data_snapshot,
        indicators=indicators,
        patterns_drift=patterns_drift,
        timeline=timeline,
    )
    console.print("[green]RUN OK[/green]", res["run_id"])
    return 0


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="emte", description="EMTE Development Console (Lab)")
    p.add_argument("--core", default=str(DEFAULT_CORE_PATH))
    p.add_argument("--outputs", default=str(DEFAULT_OUTPUTS))

    sub = p.add_subparsers(dest="cmd", required=True)

    s0 = sub.add_parser("verify-core", help="Verify vendor/emte-core is pristine and pinned")
    s0.set_defaults(fn=cmd_verify_core)

    s1 = sub.add_parser("run", help="Run EMTE harness and write canonical artifacts")
    s1.add_argument("--profile", required=True)
    s1.add_argument("--baseline-window", type=int, default=28)
    s1.set_defaults(fn=cmd_run)

    s2 = sub.add_parser("registry", help="Show registry index")
    s2.set_defaults(fn=cmd_registry)

    return p


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()
    return int(args.fn(args))
