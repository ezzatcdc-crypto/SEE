from __future__ import annotations

import os
import subprocess
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class CoreState:
    path: Path
    head_commit: str
    status_porcelain: str
    described_tag: str | None


class CoreGuardError(RuntimeError):
    pass


def _git(args: list[str], cwd: Path) -> str:
    p = subprocess.run(
        ["git", *args],
        cwd=str(cwd),
        check=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
    )
    return p.stdout.strip()


def read_core_state(core_path: Path) -> CoreState:
    if not core_path.exists():
        raise CoreGuardError(f"Core path missing: {core_path}")

    if not (core_path / ".git").exists():
        # submodules often have a gitfile, but ensure git works
        try:
            _git(["rev-parse", "--is-inside-work-tree"], cwd=core_path)
        except Exception as e:
            raise CoreGuardError(f"Core path is not a git work tree: {core_path}") from e

    head = _git(["rev-parse", "HEAD"], cwd=core_path)
    status = _git(["status", "--porcelain"], cwd=core_path)

    tag = None
    try:
        # best-effort: return tag if exactly at a tag
        tag = _git(["describe", "--tags", "--exact-match"], cwd=core_path)
    except subprocess.CalledProcessError:
        tag = None

    return CoreState(path=core_path, head_commit=head, status_porcelain=status, described_tag=tag)


def assert_core_frozen(core_path: Path, required_tag: str) -> CoreState:
    st = read_core_state(core_path)

    if st.status_porcelain.strip():
        raise CoreGuardError(
            "Core has local modifications (forbidden). "
            "vendor/emte-core must remain pristine.\n"
            f"porcelain:\n{st.status_porcelain}"
        )

    if st.described_tag != required_tag:
        raise CoreGuardError(
            "Core tag mismatch (forbidden).\n"
            f"Required tag: {required_tag}\n"
            f"Found tag:    {st.described_tag}\n"
            f"HEAD:         {st.head_commit}"
        )

    return st


def is_read_only_path(p: Path) -> bool:
    # simple OS-level heuristic; not a security boundary
    try:
        test = p / ".write_test"
        with open(test, "w", encoding="utf-8") as f:
            f.write("x")
        os.remove(test)
        return False
    except Exception:
        return True
