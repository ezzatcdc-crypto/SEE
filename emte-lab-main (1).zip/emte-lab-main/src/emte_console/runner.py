from __future__ import annotations

from pathlib import Path
from typing import Any, Dict

from emte_console.core_guard import assert_core_frozen
from emte_console.artifacts.writer import write_json, json_hash, build_run_id
from emte_console.artifacts.registry import update_registry


def run_emte(
    *,
    vendor_core_path: Path,
    required_core_tag: str,
    outputs_root: Path,
    lab_version: str,
    created_utc: str,                 # ISO8601 e.g. 2026-02-13T12:34:56Z
    created_utc_compact: str,         # 20260213T123456Z
    inputs: Dict[str, Any],
    data_snapshot: Dict[str, Any],
    indicators: Dict[str, Any],
    patterns_drift: Dict[str, Any],
    timeline: Dict[str, Any],
) -> Dict[str, Any]:
    # 1) core immutability check
    core_state = assert_core_frozen(vendor_core_path, required_tag=required_core_tag)

    # 2) deterministic run id
    dataset_hash8 = json_hash(data_snapshot)[:8]
    cfg_hash8 = json_hash(inputs)[:8]
    run_id = build_run_id(created_utc_compact, required_core_tag, dataset_hash8, cfg_hash8)

    # 3) output tree
    run_dir = outputs_root / "runs" / run_id
    def rel(p: Path) -> str:
        return str(p.relative_to(outputs_root))

    # 4) write canonical artifacts
    write_json(run_dir / "data_snapshot.json", data_snapshot)
    write_json(run_dir / "indicators.json", indicators)
    write_json(run_dir / "patterns_drift.json", patterns_drift)
    write_json(run_dir / "timeline.json", timeline)

    manifest: Dict[str, Any] = {
        "run_id": run_id,
        "created_utc": created_utc,
        "core_tag": required_core_tag,
        "core_head": core_state.head_commit,
        "lab_version": lab_version,
        "inputs": inputs,
        "outputs": {
            "run_manifest.json": rel(run_dir / "run_manifest.json"),
            "data_snapshot.json": rel(run_dir / "data_snapshot.json"),
            "indicators.json": rel(run_dir / "indicators.json"),
            "patterns_drift.json": rel(run_dir / "patterns_drift.json"),
            "timeline.json": rel(run_dir / "timeline.json"),
        },
    }
    write_json(run_dir / "run_manifest.json", manifest)

    # 5) registry update
    registry_path = outputs_root / "registry" / "index.json"
    update_registry(registry_path, {"run_id": run_id, "created_utc": created_utc})

    return {"run_id": run_id, "run_dir": str(run_dir)}
