from pathlib import Path

from emte_console.core_guard import CoreGuardError, read_core_state


def test_read_core_state_missing_path(tmp_path: Path) -> None:
    missing = tmp_path / "nope"
    try:
        read_core_state(missing)
        assert False, "Expected CoreGuardError"
    except CoreGuardError:
        assert True
